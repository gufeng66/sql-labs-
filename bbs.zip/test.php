1	2	3	<?php phpinfo();?>
