<html>
<head>
    <meta charset="utf-8">
    <title>  注册----今日论坛</title>
 
</head>
<body>
    <h1>今日论坛BBS</h1>
    <form 
        action="./addUser.php"
        method="post"
    >
        用户名：<input type="text" name="userName"><br/>
        密码：<input type="password" name="userPass1"><br/>
        确认密码：<input type="password" name="userPass2"><br/>
        <input type="submit" name="userSubmit"  value="注册">
    </form>
    <hr/>
</body>
</html>